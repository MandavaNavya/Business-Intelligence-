CREATE TABLE TB_ShipMethod (
    ShipMethodID INT NOT NULL,
    ShipMethodName VARCHAR(100),
    ShipBase DECIMAL(10, 2),
    ShipRate DECIMAL(10, 2),
    CONSTRAINT PK_ShipMethod PRIMARY KEY (ShipMethodID)
);
