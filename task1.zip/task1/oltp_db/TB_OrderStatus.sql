CREATE TABLE TB_OrderStatus (
    OrderStatusID INT NOT NULL,
    OrderStatusName VARCHAR(100) NOT NULL,
    CONSTRAINT PK_OrderStatus PRIMARY KEY (OrderStatusID)
);
