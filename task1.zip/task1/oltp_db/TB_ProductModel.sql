CREATE TABLE TB_ProductModel (
    ProductModelID INT NOT NULL,
    ProductModelName VARCHAR(255) NOT NULL,
    CONSTRAINT PK_ProductModel PRIMARY KEY (ProductModelID)
);
