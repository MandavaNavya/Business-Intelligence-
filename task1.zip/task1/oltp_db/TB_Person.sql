CREATE TABLE TB_Person (
    PersonID INT NOT NULL,
    FirstName VARCHAR(100) NOT NULL,
    MiddleName VARCHAR(100),
    LastName VARCHAR(100) NOT NULL,
    Gender CHAR(1) NOT NULL,
    BirthDate DATE NOT NULL,
    CONSTRAINT PK_Person PRIMARY KEY (PersonID)
);
