CREATE TABLE TB_SalesOrderDetail (
    SalesOrderDetailID INT ,
    SalesOrderID INT,
    ProductID INT,
    OrderQty INT,
    UnitPrice DECIMAL(10, 2),
    CONSTRAINT PK_SalesOrderDetail PRIMARY KEY (SalesOrderDetailID),
    CONSTRAINT FK_SalesOrder_SalesOrderDetail FOREIGN KEY (SalesOrderID) REFERENCES TB_SalesOrderHeader(SalesOrderID),
    CONSTRAINT FK_Product_SalesOrderDetail FOREIGN KEY (ProductID) REFERENCES TB_Product(ProductID)
);
