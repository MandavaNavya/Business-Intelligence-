CREATE TABLE TB_Address (
    AddressID INT NOT NULL,
    CountryID INT NOT NULL,
    AddressLine VARCHAR(255) NOT NULL,
    City VARCHAR(100) NOT NULL,
    PostalCode VARCHAR(50) NOT NULL,
    CONSTRAINT PK_Address PRIMARY KEY (AddressID),
    CONSTRAINT FK_Country_Address FOREIGN KEY (CountryID) REFERENCES TB_Country(CountryID)
);
