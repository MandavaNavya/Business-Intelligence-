CREATE TABLE TB_ProductTopCategory (
    ProductTopCategoryID INT NOT NULL,
    Name VARCHAR(255) NOT NULL,
    ShipSurcharge DECIMAL(13, 4) NOT NULL,
    CONSTRAINT PK_ProductTopCategory PRIMARY KEY (ProductTopCategoryID)
);
