SELECT 
    c.FullName AS CustomerName,
    SUM(f.OrderLineProfit) AS Profit
FROM 
    BI_BikesDW_47.Fact_InternetSales f
JOIN 
    BI_BikesDW_47.Dim_Date d
    ON f.OrderDateKey = d.DateKey
JOIN 
    BI_BikesDW_47.Dim_Customer c
    ON f.CustomerKey = c.CustomerKey
WHERE 
    d.CalendarYear = 2021 
    AND d.MonthNumberOfYear BETWEEN 1 AND 6
GROUP BY 
    c.FullName
ORDER BY 
    Profit DESC
LIMIT 10;
