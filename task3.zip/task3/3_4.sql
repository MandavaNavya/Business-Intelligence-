SELECT 
    c.FullName AS CustomerName,
    SUM(f.OrderQty) AS QuantitySold,
    l.Region
FROM 
    BI_BikesDW_47.Fact_InternetSales f
JOIN 
    BI_BikesDW_47.Dim_Customer c
    ON f.CustomerKey = c.CustomerKey
JOIN 
    BI_BikesDW_47.Dim_Location l
    ON f.ShipToLocationKey = l.LocationKey
WHERE 
    l.Region = 'Europe'
GROUP BY 
    c.FullName, l.Region
ORDER BY 
    QuantitySold DESC
LIMIT 5;
