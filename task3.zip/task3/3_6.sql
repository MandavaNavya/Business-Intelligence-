WITH RankedProducts AS (
    SELECT
        p.ProductTopCategoryName,
        p.ProductSubCategoryName,
        p.ProductModelName,
        SUM(f.OrderQty) AS QuantitySold,
        ROW_NUMBER() OVER (
            PARTITION BY p.ProductTopCategoryName
            ORDER BY SUM(f.OrderQty) DESC
        ) AS ProductRank  -- Changed from 'Rank' to 'ProductRank'
    FROM 
        BI_BikesDW_47.Fact_InternetSales f
    JOIN 
        BI_BikesDW_47.Dim_Product p 
        ON f.ProductKey = p.ProductKey
    GROUP BY 
        p.ProductTopCategoryName,
        p.ProductSubCategoryName,
        p.ProductModelName
)
SELECT 
    ProductTopCategoryName,
    ProductSubCategoryName,
    ProductModelName,
    QuantitySold
FROM 
    RankedProducts
WHERE 
    ProductRank <= 3  -- Changed from 'Rank' to 'ProductRank'
ORDER BY 
    ProductTopCategoryName,
    QuantitySold DESC;