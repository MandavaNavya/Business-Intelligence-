SELECT
    d.CalendarYear,
    d.EnglishMonthName AS Month,
    d.MonthNumberOfYear,
    l.Country,
    COALESCE(SUM(f.OrderLineTaxAmt), 0) AS TaxAmount
FROM 
    BI_BikesDW_47.Fact_InternetSales f
JOIN 
    BI_BikesDW_47.Dim_Date d 
    ON f.OrderDateKey = d.DateKey
JOIN 
    BI_BikesDW_47.Dim_Location l 
    ON f.ShipToLocationKey = l.LocationKey
WHERE 
    d.CalendarYear = 2021
    AND d.MonthNumberOfYear BETWEEN 1 AND 6
    AND l.Country IN ('France', 'Germany')
GROUP BY 
    d.CalendarYear,
    d.EnglishMonthName,
    d.MonthNumberOfYear,
    l.Country
ORDER BY 
    d.CalendarYear,
    d.MonthNumberOfYear,
    l.Country;
