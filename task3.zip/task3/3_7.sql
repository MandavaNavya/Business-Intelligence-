WITH RankedCountries AS (
    SELECT
        l.Country,
        SUM(f.OrderLineProfit) AS TotalProfit,
        ROW_NUMBER() OVER (
            ORDER BY SUM(f.OrderLineProfit) DESC
        ) AS CountryRank
    FROM 
        BI_BikesDW_47.Fact_InternetSales f
    JOIN 
        BI_BikesDW_47.Dim_Location l 
        ON f.ShipToLocationKey = l.LocationKey
    JOIN 
        BI_BikesDW_47.Dim_Product p 
        ON f.ProductKey = p.ProductKey
    WHERE 
        p.ListPrice BETWEEN 1000 AND 2000 -- Price range filter
    GROUP BY 
        l.Country
)
SELECT 
    Country,
    TotalProfit
FROM 
    RankedCountries
WHERE 
    CountryRank <= 3
ORDER BY 
    TotalProfit DESC;

