INSERT INTO BI_BikesDW_47.Dim_Location (
    LocationKey,
    Country,
    Region,
    TaxRate,
    ShipCoeff
)
SELECT 
    A.AddressID AS LocationKey,
    C.Country,
    C.Region,
    C.TaxRate,
    C.ShipCoeff
FROM 
    BI_Bikes_47.TB_Address A
JOIN 
    BI_Bikes_47.TB_Country C ON A.CountryID = C.CountryID;


