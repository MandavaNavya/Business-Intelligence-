INSERT INTO Dim_Product (
    ProductKey, ProductName, ProductNumber, ProductModelName,
    ProductSubCategoryName, ProductTopCategoryName,
    StandardCost, ListPrice, ProductStatus, StartDate, EndDate
)
SELECT 
    P.ProductID AS ProductKey,
    P.ProductName,
    P.ProductNumber,
    PM.ProductModelName,
    PSC.Name AS ProductSubCategoryName,
    PTC.Name AS ProductTopCategoryName,
    P.StandardCost,
    P.ListPrice,
    CASE 
        WHEN P.SellEndDate IS NULL OR P.SellEndDate > '2021-09-30' THEN 'Current'
        ELSE 'Discontinued'
    END AS ProductStatus,
    P.SellStartDate AS StartDate,
    P.SellEndDate AS EndDate
FROM 
    BI_Bikes_47.TB_Product P
LEFT JOIN 
    BI_Bikes_47.TB_ProductModel PM ON P.ProductModelID = PM.ProductModelID
LEFT JOIN 
    BI_Bikes_47.TB_ProductSubCategory PSC ON P.ProductSubCategoryID = PSC.ProductSubCategoryID
LEFT JOIN 
    BI_Bikes_47.TB_ProductTopCategory PTC ON PSC.ProductTopCategoryID = PTC.ProductTopCategoryID;






