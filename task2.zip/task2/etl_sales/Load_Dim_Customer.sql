INSERT INTO BI_BikesDW_47.Dim_Customer (
    CustomerKey, 
    AccountNumber, 
    FullName, 
    Gender, 
    Age
)
SELECT 
    C.CustomerID AS CustomerKey,                             
    COALESCE(C.AccountNumber, 'N/A') AS AccountNumber,                                         
    CONCAT(
        P.FirstName, 
        ' ', 
        IFNULL(P.MiddleName, ''), 
        CASE WHEN P.MiddleName IS NOT NULL AND P.MiddleName != '' THEN ' ' ELSE '' END, 
        P.LastName
    ) AS FullName, 
    COALESCE(P.Gender, 'Unknown') AS Gender,                                               
    CASE 
        WHEN P.BirthDate IS NULL THEN 0 
        ELSE TIMESTAMPDIFF(YEAR, P.BirthDate, '2021-09-30') 
    END AS Age    
FROM 
    BI_Bikes_47.TB_Customer C
JOIN 
    BI_Bikes_47.TB_Person P ON C.PersonID = P.PersonID;




