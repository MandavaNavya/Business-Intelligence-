INSERT INTO BI_BikesDW_47.Fact_InternetSales (
    SalesOrderLineNumber,
    SalesOrderNumber,
    OrderDate,
    DueDate,
    ShipDate,
    OrderDateKey,
    DueDateKey,
    ShipDateKey,
    ProductKey,
    CustomerKey,
    ShipToLocationKey,
    OrderStatus,
    ShipMethod,
    OrderQty,
    UnitPrice,
    OrderLineTotal,
    OrderLineProfit,
    OrderLineTaxAmt,
    OrderLineShippingCost
)
SELECT 
    CONCAT('SOL', SOH.SalesOrderID, '-', SOD.SalesOrderDetailID) AS SalesOrderLineNumber,
    SOH.SalesOrderNumber AS SalesOrderNumber,
    SOH.OrderDate AS OrderDate, 
    SOH.DueDate AS DueDate,   
    SOH.ShipDate AS ShipDate, 
    YEAR(SOH.OrderDate) * 10000 + MONTH(SOH.OrderDate) * 100 + DAYOFMONTH(SOH.OrderDate) AS OrderDateKey,
    YEAR(SOH.DueDate) * 10000 + MONTH(SOH.DueDate) * 100 + DAYOFMONTH(SOH.DueDate) AS DueDateKey,
    YEAR(SOH.ShipDate) * 10000 + MONTH(SOH.ShipDate) * 100 + DAYOFMONTH(SOH.ShipDate) AS ShipDateKey,
    SOD.ProductID AS ProductKey,
    SOH.CustomerID AS CustomerKey,
    SOH.ShipToAddressID AS ShipToLocationKey,
    OS.OrderStatusName AS OrderStatus,
    SM.ShipMethodName AS ShipMethod,
    SOD.OrderQty AS OrderQty,
    SOD.UnitPrice AS UnitPrice,
    SOD.OrderQty * SOD.UnitPrice AS OrderLineTotal,
    (SOD.OrderQty * SOD.UnitPrice) - (SOD.OrderQty * P.StandardCost) AS OrderLineProfit,
    SOD.OrderQty * 0 AS OrderLineTaxAmt,
    PTC.ShipSurcharge + SM.ShipBase + (SOD.OrderQty * SM.ShipRate) AS OrderLineShippingCost
FROM 
    BI_Bikes_47.TB_SalesOrderHeader SOH
JOIN 
    BI_Bikes_47.TB_SalesOrderDetail SOD ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN 
    BI_Bikes_47.TB_Product P ON SOD.ProductID = P.ProductID
JOIN
    BI_Bikes_47.TB_ProductSubCategory PSC ON P.ProductSubCategoryID = PSC.ProductSubCategoryID
JOIN
    BI_Bikes_47.TB_ProductTopCategory PTC ON PSC.ProductTopCategoryID = PTC.ProductTopCategoryID
LEFT JOIN 
    BI_Bikes_47.TB_OrderStatus OS ON SOH.OrderStatusID = OS.OrderStatusID
LEFT JOIN 
    BI_Bikes_47.TB_ShipMethod SM ON SOH.ShipMethodID = SM.ShipMethodID;







