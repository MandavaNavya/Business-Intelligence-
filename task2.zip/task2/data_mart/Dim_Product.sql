CREATE TABLE Dim_Product (
    ProductKey INT NOT NULL,
    ProductName VARCHAR(255) NOT NULL,
    ProductNumber VARCHAR(50),
    ProductModelName VARCHAR(255),
    ProductSubCategoryName VARCHAR(50),
    ProductTopCategoryName VARCHAR(50),
    StandardCost DECIMAL(13, 4),
    ListPrice DECIMAL(13, 4),
    ProductStatus VARCHAR(50),
    StartDate DATE,
    EndDate DATE,
    CONSTRAINT PK_DimProduct PRIMARY KEY (ProductKey)
);



