CREATE TABLE Dim_Date (
    DateKey INT NOT NULL,
    FullDateAlternateKey DATE,
    DayNumberOfWeek INT,
    EnglishDayNameOfWeek VARCHAR(15),
    DayNumberOfMonth INT,
    WeekNumberOfYear INT,
    EnglishMonthName VARCHAR(15),
    MonthNumberOfYear INT,
    CalendarQuarter INT,
    CalendarYear INT,
    CONSTRAINT PK_DimDate PRIMARY KEY (DateKey)
);


