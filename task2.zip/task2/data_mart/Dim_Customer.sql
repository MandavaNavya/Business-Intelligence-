CREATE TABLE BI_BikesDW_47.Dim_Customer (
    CustomerKey INT NOT NULL,
    AccountNumber VARCHAR(50) NOT NULL,
    FullName VARCHAR(150) NOT NULL,
    Gender VARCHAR(10) NOT NULL,
    Age INT NOT NULL,
    CONSTRAINT PK_DimCustomer PRIMARY KEY (CustomerKey)
);
